
# Online Shopping Analytics Project

## Introduction

In today's digital era, online shopping has become a significant part of consumer behavior. This project focuses on analyzing transactional data to provide valuable insights into customer purchasing habits, product performance, and sales trends.

## Project Objectives

The main goals of this project are:
1. **Understand customer behavior** by analyzing demographic and transactional data.
2. **Identify trends** in product sales and categories.
3. **Evaluate promotional strategies** by studying discounts, coupons, and their effects on sales.

## Tools and Technologies Used

- **SQL**: For database management and executing queries.
- **Python**: For data cleaning and analysis.
- **Tableau**: For creating interactive visualizations.

## Project Structure

### SQL Script Overview

The SQL script, `Project SQL Script.sql`, performs the following operations:
1. **Database Setup**: Creates a new database `OnlineShopping`.
2. **Table Creation**: Defines tables such as `Transactions` with fields like `CustomerID`, `Gender`, `Location`, `Product_SKU`, `Avg_Price`, etc.
3. **Data Insertion**: Populates the tables with sample data.
4. **Query Execution**: Includes queries to extract insights, such as top-performing products, high-value customers, and regional sales trends.

#### Sample SQL Code:
```sql
-- Using the onlineshopping data set
USE OnlineShopping;

-- Creating Transactions table
CREATE TABLE Transactions (
    ID INT,
    CustomerID INT PRIMARY KEY,
    Gender VARCHAR(40),
    Location VARCHAR(100),
    Product_SKU VARCHAR(20),
    Avg_Price DECIMAL(10, 2),
    Quantity INT,
    Total_Spend DECIMAL(12, 2)
);
```

### Data Sample

The dataset contains transactional details such as:
- **CustomerID**: Unique identifier for customers.
- **Product_SKU**: Product identification code.
- **Location**: Customer location.
- **Avg_Price**: Average price of the product.
- **Quantity**: Number of products purchased.

#### Sample Data:
| ID | CustomerID | Gender | Location | Product_SKU | Avg_Price | Quantity | Total_Spend |
|----|------------|--------|----------|-------------|-----------|----------|-------------|
| 1  | 1001       | F      | New York | ABC123      | 120.50    | 2        | 241.00      |
| 2  | 1002       | M      | Chicago  | DEF456      | 89.99     | 1        | 89.99       |

## Key Insights

This project provides insights into:
1. **Customer Segmentation**: Grouping customers based on their purchase behavior.
2. **Product Analysis**: Identifying top-selling products and underperformers.
3. **Sales Performance**: Analyzing regional sales trends and seasonal effects.

### Visualizations

The analysis is accompanied by interactive dashboards created using Tableau to visualize key findings.

![Sample Visualization](https://via.placeholder.com/1024x768.png?text=Sample+Dashboard)

## Step-by-Step Guide

1. **Database Setup**: Run the `Project SQL Script.sql` file in your SQL environment to create the database and tables.
2. **Data Analysis**: Use Python scripts to perform further data exploration and manipulation.
3. **Visualization**: Open the Tableau dashboard file to explore visual insights.

## Conclusion

This project demonstrates how data analysis and visualization can drive business decisions by providing actionable insights into customer behavior and sales performance.

## Authors

- [Your Name] - Data Analyst

## License

This project is licensed under the MIT License - see the LICENSE file for details.


## Dashboard Insights

### Customer Demographic
The **Customer Demographic Dashboard** reveals a notable gender distribution, with a significant skew towards females across all locations. Additionally, female customers exhibit a longer average tenure on the platform compared to their male counterparts. Further exploration is recommended to understand the gender distribution concerning specific product categories.

### Sales Analysis
The **Sales Analysis Dashboard** uncovers that office items dominate in terms of the number of sales, constituting 37% of the platform's total sales. Surprisingly, offline spending contributes significantly to the overall customer expenditure, meaning that in-store sales are still superior to online sales. Contrary to initial assumptions, the correlation between discounts and total sales or customer spending is not as substantial.

### Location Analysis
The **Location Analysis Dashboard** highlights the outstanding performance of Chicago and California compared to New York, New Jersey, and Washington D.C. Interestingly, apparels emerge as the leading category in terms of total spending in Chicago and California, contrary to the fact that office items are the most frequently purchased.

### Consumer Spending
Examining the **Consumer Spending Dashboard** reveals that the highest spending customers predominantly invest in apparel, Nest, office, and drinkware items. This aligns well with the findings in other dashboards concerning product categories.

### Coupon Engagement
The **Coupon Engagement Analysis** indicates that the coupon usage rate remains relatively constant throughout the year, despite fluctuations in the number of coupons clicked, peaking in August. This suggests that the current coupon discounts may not be compelling enough to significantly impact customer purchasing behavior.


## SQL Queries and Analysis

### 1. Top 10 Highest Spending Customers
```sql
SELECT CustomerID, SUM(Online_Spend) AS Total_Spend
FROM Transactions
GROUP BY CustomerID
ORDER BY Total_Spend DESC
LIMIT 10;
```
**Analysis:**  
This query identifies the top 10 customers based on their total online spending. These customers are crucial for business growth, and targeted marketing strategies can be developed to retain them and increase their loyalty.

---

### 2. Popular Product Categories
```sql
SELECT Product_Category, SUM(Quantity) AS Total_Quantity
FROM Transactions
GROUP BY Product_Category
ORDER BY Total_Quantity DESC;
```
**Analysis:**  
This query provides insight into the most popular product categories in terms of quantity sold. Understanding these trends helps in inventory management and promotional planning.

---

### 3. Monthly Spending Trends
```sql
SELECT Month, SUM(Online_Spend + Offline_Spend) AS Total_Monthly_Spend
FROM Transactions
GROUP BY Month
ORDER BY Month;
```
**Analysis:**  
Analyzing monthly spending trends enables businesses to identify peak shopping periods and plan sales and promotions accordingly.

---

### 4. Coupon Usage Analysis
```sql
SELECT Coupon_Code, COUNT(*) AS Usage_Count, AVG(Discount_pct) AS Avg_Discount
FROM Transactions
WHERE Coupon_Status = 'Used'
GROUP BY Coupon_Code
ORDER BY Usage_Count DESC;
```
**Analysis:**  
This query examines the effectiveness of different coupons by analyzing their usage frequency and average discount offered. It helps assess which coupon codes are most attractive to customers.

---

### 5. Product Sales Breakdown
```sql
SELECT Product_SKU, Product_Description, SUM(Quantity) AS Total_Sales
FROM Transactions
GROUP BY Product_SKU, Product_Description
ORDER BY Total_Sales DESC
LIMIT 10;
```
**Analysis:**  
This query lists the top 10 products based on the number of units sold, helping identify bestsellers.

---

### 6. Highest Transaction Value
```sql
SELECT Transaction_ID, (Online_Spend + Offline_Spend) AS Total_Value
FROM Transactions
ORDER BY Total_Value DESC
LIMIT 1;
```
**Analysis:**  
Identifying the highest transaction value can provide insights into big-ticket purchases, aiding in understanding customer spending behavior.

---

### 7. Total Spending by Location
```sql
SELECT Location, SUM(Online_Spend + Offline_Spend) AS Total_Spend
FROM Transactions
GROUP BY Location
ORDER BY Total_Spend DESC;
```
**Analysis:**  
This query highlights the total spending in each location, enabling businesses to target high-performing regions more effectively.

---

### 8. Top Spending Locations for Each Gender
```sql
SELECT Gender, Location, SUM(Online_Spend + Offline_Spend) AS Total_Spend
FROM Transactions
GROUP BY Gender, Location
ORDER BY Gender, Total_Spend DESC;
```
**Analysis:**  
This analysis provides a gender-based spending breakdown by location, helping tailor location-specific marketing campaigns.

---

### 9. Online vs. Offline Spend
```sql
SELECT CustomerID, 'Online' AS Spend_Type, SUM(Online_Spend) AS Total_Spend
FROM Transactions
GROUP BY CustomerID
UNION ALL
SELECT CustomerID, 'Offline' AS Spend_Type, SUM(Offline_Spend) AS Total_Spend
FROM Transactions
GROUP BY CustomerID
ORDER BY CustomerID, Spend_Type;
```
**Analysis:**  
This query compares online and offline spending for each customer, offering a comprehensive view of their purchasing behavior across channels.

---

### 10. Assign Unique Row Numbers
```sql
SELECT 
    CustomerID, 
    Transaction_ID, 
    ROW_NUMBER() OVER (PARTITION BY CustomerID ORDER BY Online_Spend DESC) AS RowNum
FROM Transactions;
```
**Analysis:**  
This query assigns a unique row number to each transaction for a customer, ordered by their online spending. It helps track individual transaction histories.

---

### 11. Cumulative Distribution of Customer Spending
```sql
SELECT 
    CustomerID, 
    SUM(Online_Spend + Offline_Spend) AS Total_Spend,
    CUME_DIST() OVER (ORDER BY SUM(Online_Spend + Offline_Spend) DESC) AS Cumulative_Distribution
FROM Transactions
GROUP BY CustomerID;
```
**Analysis:**  
This query calculates the cumulative distribution of customer spending, which can be used to classify customers into different spending tiers (e.g., top 10% of spenders).

---

### 12. Compare Current vs. Previous Transaction Spend
```sql
SELECT 
    CustomerID, 
    Transaction_ID, 
    Online_Spend, 
    LAG(Online_Spend) OVER (PARTITION BY CustomerID ORDER BY Transaction_ID) AS Previous_Spend,
    (Online_Spend - LAG(Online_Spend) OVER (PARTITION BY CustomerID ORDER BY Transaction_ID)) AS Spend_Difference
FROM Transactions;
```
**Analysis:**  
This query compares the online spending of the current transaction with the previous one for each customer, helping identify trends or anomalies in their spending behavior.

## Conclusion

This project demonstrates how data analysis and visualization can drive business decisions by providing actionable insights into customer behavior and sales performance.

**Customer Demographic:**
The Customer Demographic Dashboard reveals a notable gender distribution, with a significant skew towards females across all locations. Additionally, female customers exhibit a longer average tenure on the platform compared to their male counterparts. Further exploration is recommended to understand the gender distribution concerning specific product categories.

**Sales Analysis:**
The Sales Analysis Dashboard uncovers that office items dominate in terms of the number of sales, constituting 37% of the platform's total sales. Surprisingly, offline spending contributes significantly to the overall customer expenditure, meaning that in-store sales are still superior to online sales. Contrary to initial assumptions, the correlation between discounts and total sales or customer spending is not as substantial.

**Location Analysis:**
The Location Analysis Dashboard highlights the outstanding performance of Chicago and California compared to New York, New Jersey, and Washington D.C. Interestingly, apparels emerge as the leading category in terms of total spending in Chicago and California, contrary to the fact that office items are the most frequently purchased.

**Consumer Spending:**
Examining the Consumer Spending Dashboard reveals that the highest spending customers predominantly invest in apparel, Nest, office, and drinkware items. This aligns well with the findings in other dashboards concerning product categories.

**Coupon Engagement:**
The Coupon Engagement Analysis indicates that the coupon usage rate remains relatively constant throughout the year, despite fluctuations in the number of coupons clicked, peaking in August. This suggests that the current coupon discounts may not be compelling enough to significantly impact customer purchasing behavior.
### Authors
- Poojitha Guduru - Project Lead

### Acknowledgements
- Special thanks to Kaggle for providing the dataset.

---

## License
This project is licensed under the MIT License - see the LICENSE file for details.
